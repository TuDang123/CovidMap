initMap();
var activeInfoWindow;
function initMap(){
      // Map options
      var options = {
        zoom:2,
        center:{lat:39.8283,lng:-98.5795},
		          styles: [
            {elementType: 'geometry', stylers: [{color: '#334661'}]},
            {elementType: 'labels.text.stroke', stylers: [{color: '#242f3e'}]},
            {elementType: 'labels.text.fill', stylers: [{color: '#746855'}]},
            {
              featureType: 'administrative.locality',
              elementType: 'labels.text.fill',
              stylers: [{color: '#d59563'}]
            },
            {
              featureType: 'poi',
              elementType: 'labels.text.fill',
              stylers: [{color: '#d59563'}]
            },
            {
              featureType: 'poi.park',
              elementType: 'geometry',
              stylers: [{color: '#263c3f'}]
            },
            {
              featureType: 'poi.park',
              elementType: 'labels.text.fill',
              stylers: [{color: '#6b9a76'}]
            },
            {
              featureType: 'road',
              elementType: 'geometry',
              stylers: [{color: '#38414e'}]
            },
            {
              featureType: 'road',
              elementType: 'geometry.stroke',
              stylers: [{color: '#212a37'}]
            },
            {
              featureType: 'road',
              elementType: 'labels.text.fill',
              stylers: [{color: '#9ca5b3'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'geometry',
              stylers: [{color: '#746855'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'geometry.stroke',
              stylers: [{color: '#1f2835'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'labels.text.fill',
              stylers: [{color: '#f3d19c'}]
            },
            {
              featureType: 'transit',
              elementType: 'geometry',
              stylers: [{color: '#2f3948'}]
            },
            {
              featureType: 'transit.station',
              elementType: 'labels.text.fill',
              stylers: [{color: '#d59563'}]
            },
            {
              featureType: 'water',
              elementType: 'geometry',
              stylers: [{color: '#17263c'}]
            },
            {
              featureType: 'water',
              elementType: 'labels.text.fill',
              stylers: [{color: '#515c6d'}]
            },
            {
              featureType: 'water',
              elementType: 'labels.text.stroke',
              stylers: [{color: '#17263c'}]
            }
          ]
		 
      }

      // New map
      var map = new google.maps.Map(document.getElementById('map'), options);
		
	
	var myTableArray = [];
	$("table tr").each(function() { 
    var arrayOfThisRow = [];
    var tableData = $(this).find('td');
    if (tableData.length > 0) {
        tableData.each(function() { arrayOfThisRow.push($(this).text()); });
        myTableArray.push(arrayOfThisRow);
    }
	});
	
	var markers = myTableArray;
	

      // Loop through markers
      for(var i = 0;i < markers.length;i++){
        // Add marker
        addMarker(markers[i]);
      }

      // Add Marker Function
      function addMarker(props){
        var marker = new google.maps.Marker({
          position:{lat: parseFloat(props[1]), lng: parseFloat(props[2])},
          map:map,
				icon: {
                  path: google.maps.SymbolPath.CIRCLE,
                  scale: 5,
				  strokeWeight:1,
                  strokeColor: '#FF0000'
               },
		
		  
        });
		
		

		var cityCircle = new google.maps.Circle({
            strokeColor: '#FF0000',
            strokeOpacity: 0.4,
            strokeWeight: 0,
            fillColor: '#FF0000',
            fillOpacity: 0.4,
            map: map,
            center: {lat: parseFloat(props[1]), lng: parseFloat(props[2])},
            radius: props[3] * 100000
          });


		var infoWindow = new google.maps.InfoWindow({
			content: '<div style="font-size: 1.3em">'+ props[0].toString() + '</div>' + "<br>Confirmed Cases: " + props[3].toString()+",000"
		});	
		
		

		
		
         marker.addListener('click', function(){
				
				if(activeInfoWindow != null){
					activeInfoWindow.close();
				};
				
				infoWindow.open(map, marker);
				activeInfoWindow = infoWindow; 
          });
		  
		  
		  
		  
        }
      


}