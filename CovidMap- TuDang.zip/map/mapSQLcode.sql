-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2020 at 04:57 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `map`
--

-- --------------------------------------------------------

--
-- Table structure for table `markers`
--

CREATE TABLE `markers` (
  `id` int(4) NOT NULL,
  `name` varchar(40) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `cases` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `markers`
--

INSERT INTO `markers` (`id`, `name`, `lat`, `lng`, `cases`) VALUES
(1, 'Boston,MA', 42.360100, -71.058899, 9),
(2, 'Los Angles, CA', 34.051998, -118.242996, 7),
(5, 'Athens, GA', 33.950001, -83.383331, 3),
(6, 'Miramar, FL', 25.978889, -80.282501, 7),
(7, 'Montgomery, AL', 32.361668, -86.279167, 2),
(8, 'Vancouver, WA', 45.633331, -122.599998, 4),
(9, 'Birmingham,AL', 33.570000, -86.750000, 5),
(10, 'Dallas, TX', 32.776699, -96.796997, 5),
(12, 'New York City, NY', 40.712799, -74.005997, 10),
(13, 'Beijing, China', 39.904202, 116.407402, 9),
(14, 'Seoul, Korea', 37.566502, 126.977997, 9),
(15, 'Tokyo, Japan', 35.680401, 139.768997, 8),
(16, 'Sydney, Australia', -33.868801, 151.209305, 7),
(17, 'Tehran, Iran', 35.689201, 51.389000, 10),
(18, 'Rome, Italy', 41.902802, 12.496400, 10),
(19, 'Moscow, Russia', 55.755798, 37.617298, 6),
(20, 'London, England', 51.507401, -0.127800, 7),
(21, 'Alaska, USA', 64.200798, -149.493698, 3),
(22, 'Istanbul, Turkey', 41.015137, 28.979530, 7),
(23, 'Sao Paulo, Brazil', -23.550501, -46.633301, 5),
(24, 'Lagos, Nigeria', 6.524400, 3.379200, 6),
(25, 'Wuhan, China', 30.592800, 114.305496, 9),
(26, 'Caracas, Venezuela', 10.480600, -66.903603, 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `markers`
--
ALTER TABLE `markers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `markers`
--
ALTER TABLE `markers`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
