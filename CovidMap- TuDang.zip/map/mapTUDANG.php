
<!DOCTYPE html >

<html>
  <head>

    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript" src="mapJS.js"></script>
    <title>Covid-19 tracking  map</title>
    <style>
      #map {
        height: 600px;
		width: 70%;
		float: left;
      }
body {background-color: black;}	

h2,span {color: white; text-align: center;}

span {font-size: 0.7em;}    

table,th,td,tr {
	border: 1px solid black;
	border-radius: 5px;
	width: 30%;
	margin: 5px;
	background-color: white;
	max-height: 500px;

}


    </style>
  </head>

  <body>
  <h2>COVID-19 TRACKING MAP <span>by Tu Dang</span></h2>

   <div id="map"></div>
	<div>
	<?php
	
	$severname ="localhost";
	$sever_username = "root";
	$sever_password = "";
	$dbName = "map";
	
	// Create connection
	$conn = new mysqli($severname, $sever_username, $sever_password, $dbName);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	$sql = "SELECT * FROM markers ORDER BY markers.cases DESC";
	
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				echo '<table id="table" style="text-align:center; margin: auto">
				<tr>
				<th>City Name</th>
				<th style="display: none">Latitude</th>
				<th style="display: none">Longitude</th>
				<th>Confirmed Cases (thousand)</th>
				</tr>';
				while($row = $result->fetch_assoc()) {
					echo "<tr><td>";
					echo $row["name"];
					echo "</td><td style='display: none'>";
					echo $row["lat"];
					echo "</td><td style='display: none'>";
					echo $row["lng"];
					echo "</td><td>";
					echo $row["cases"];
					echo "</td></tr>";
			
				}
				echo "</table>";
			}
	?>
	
	</div>
	
	<p id="checkArray"></p>
	<script type="text/javascript">
		 
	
	</script>
   
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAChk4ryq5fHGLYTnIIoc-z0QUzYSCvmRw&callback=initMap">
    </script>
  </body>
</html>